import logging
import ask_sdk_core.utils as ask_utils
from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler, AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_core.utils import is_intent_name, get_slot
from ask_sdk_model import Response
from ask_sdk_model.dialog import ElicitSlotDirective

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

sb = SkillBuilder()

MAX_RETRIES = 5 # Max No of times VA tries to reprompt in 1 conversation flow.

class LaunchRequestHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # Initialize session attributes including retry counter
        handler_input.attributes_manager.session_attributes = {
            'retries': 0
        }
        return handler_input.response_builder.speak(
            "Welcome to Quick Scoop! To get started with your order, Say 'Order ice cream with quantity and dietary preference'."
        ).ask("Try saying 'order ice cream'").response

class OrderIceCreamIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("OrderIceCreamIntent")(handler_input)

    def handle(self, handler_input):
        try:
            # Get session attributes
            attr = handler_input.attributes_manager.session_attributes
            retries = attr.get('retries', 0)
            
            # Check if max retries reached
            if retries >= MAX_RETRIES:
                return handler_input.response_builder.speak(
                    "I'm having trouble understanding your order. Please try again later. Goodbye!"
                ).set_should_end_session(True).response

            slots = handler_input.request_envelope.request.intent.slots
            logger.debug(f"Received slots: {slots}")

            # Get both slots initially
            quantity_slot = get_slot(handler_input, "Quantity")
            dietary_slot = get_slot(handler_input, "DietaryPreference")
            
            # Validate quantity if provided
            if quantity_slot and quantity_slot.value:
                try:
                    quantity = int(quantity_slot.value)
                    if quantity > 50 or quantity < 1:
                        # Increment retry counter
                        attr['retries'] = retries + 1
                        handler_input.attributes_manager.session_attributes = attr
                        
                        return handler_input.response_builder.speak(
                            f"Stores around can serve between 1 and 50 ice creams pints per order. Please pick a number from this range. You have {MAX_RETRIES - retries - 1} attempts remaining."
                        ).add_directive(
                            ElicitSlotDirective(slot_to_elicit="Quantity")
                        ).ask("How many ice creams would you like?").response
                except ValueError:
                    # Increment retry counter for invalid number format
                    attr['retries'] = retries + 1
                    handler_input.attributes_manager.session_attributes = attr
                    return self._elicit_quantity(handler_input, MAX_RETRIES - retries - 1)
            
            # If either slot is missing, ask for both
            if (not quantity_slot or not quantity_slot.value or 
                not dietary_slot or not dietary_slot.value):
                # Increment retry counter
                attr['retries'] = retries + 1
                handler_input.attributes_manager.session_attributes = attr
                
                missing_slots = []
                if not quantity_slot or not quantity_slot.value:
                    missing_slots.append("quantity")
                if not dietary_slot or not dietary_slot.value:
                    missing_slots.append("dietary preference")
                
                speak_text = f"Please provide both {' and '.join(missing_slots)}. "
                speak_text += "For quantity, choose between 1-50. "
                speak_text += "For dietary preference, choose regular, vegan, sugar-free, or dairy-free. "
                speak_text += f"You have {MAX_RETRIES - retries - 1} attempts remaining."
                
                return handler_input.response_builder.speak(speak_text).ask(
                    "Please provide the missing information"
                ).response

            quantity = int(quantity_slot.value)
            dietary = dietary_slot.value.lower()

            # Validate dietary preference
            valid_preferences = ["regular", "vegan", "dairy-free", "sugar-free", 
                               "sugar free", "dairy free", "gluten-free", "gluten free"]
            if dietary not in valid_preferences:
                # Increment retry counter
                attr['retries'] = retries + 1
                handler_input.attributes_manager.session_attributes = attr
                return self._handle_invalid_dietary(handler_input, MAX_RETRIES - retries - 1)

            # Reset retry counter on successful order
            attr['retries'] = 0
            handler_input.attributes_manager.session_attributes = attr

            return handler_input.response_builder.speak(
                f"Order confirmed! {quantity} {dietary} ice cream{'s' if quantity > 1 else ''} coming soon!"
            ).set_should_end_session(True).response

        except Exception as e:
            logger.error(f"Error: {str(e)}", exc_info=True)
            # Increment retry counter for exceptions
            attr = handler_input.attributes_manager.session_attributes
            retries = attr.get('retries', 0) + 1
            attr['retries'] = retries
            handler_input.attributes_manager.session_attributes = attr
            
            if retries >= MAX_RETRIES:
                return handler_input.response_builder.speak(
                    "I'm having trouble processing your order. Please try again later. Goodbye!"
                ).set_should_end_session(True).response
            
            return handler_input.response_builder.speak(
                f"Sorry, there was an error processing your order. Please try again by saying 'order ice cream'. You have {MAX_RETRIES - retries} attempts remaining."
            ).ask("Try saying 'order ice cream'").response

    def _elicit_quantity(self, handler_input, attempts_remaining):
        return handler_input.response_builder.speak(
            f"How many ice creams would you like? Please choose between 1 and 50. You have {attempts_remaining} attempts remaining."
        ).add_directive(
            ElicitSlotDirective(slot_to_elicit="Quantity")
        ).ask("Unfortunately the stores allow only up to 50 pints per order. Say a number between 1 and 50").response

    def _handle_invalid_dietary(self, handler_input, attempts_remaining):
        return handler_input.response_builder.speak(
            f"Please choose regular, vegan, or dairy-free for your ice cream preference. You have {attempts_remaining} attempts remaining."
        ).add_directive(
            ElicitSlotDirective(slot_to_elicit="DietaryPreference")
        ).ask("What type of ice cream would you like?").response

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(OrderIceCreamIntentHandler())

lambda_handler = sb.lambda_handler()