const functions = require("firebase-functions");
const { WebhookClient } = require("dialogflow-fulfillment");

const iceCreamShops = [
    { name: "Salt & Straw", location: "Portland", area: "Pearl District", dietaryOptions: ["vegan", "dairy-free", "regular"], flavors: ["chocolate", "vanilla", "strawberry"], hours: "11am-11pm", rating: 4.8 },
    { name: "Fifty Licks", location: "Portland", area: "Division", dietaryOptions: ["regular", "gluten-free"], flavors: ["mint chip", "chocolate"], hours: "12pm-10pm", rating: 4.6 },
    { name: "Kulfi PDX", location: "Portland", area: "Downtown", dietaryOptions: ["regular"], flavors: ["gulab jamun", "vanilla"], hours: "12pm-9pm", rating: 4.7 },
    { name: "Molly Moon's", location: "Seattle", area: "Capitol Hill", dietaryOptions: ["vegan", "regular"], flavors: ["salted caramel", "honey lavender"], hours: "12pm-11pm", rating: 4.9 },
    { name: "Frankie & Jo's", location: "Seattle", area: "Ballard", dietaryOptions: ["vegan", "gluten-free"], flavors: ["chocolate tahini", "brown sugar vanilla"], hours: "12pm-10pm", rating: 4.8 },
    { name: "Bi-Rite Creamery", location: "San Francisco", area: "Mission District", dietaryOptions: ["regular", "gluten-free"], flavors: ["black sesame", "peach cobbler"], hours: "11am-10pm", rating: 4.8 },
    { name: "Humphry Slocombe", location: "San Francisco", area: "Ferry Building", dietaryOptions: ["regular"], flavors: ["secret breakfast", "blue bottle coffee"], hours: "12pm-11pm", rating: 4.7 }
];

function normalizeNumber(number) {
    return typeof number === 'string' ? parseInt(number, 10) || 0 : number;
}

function normalizeDietaryPreference(preference) {
    const validPreferences = ["regular", "vegan", "gluten-free", "dairy-free", "sugar-free"];
    return validPreferences.includes(preference.toLowerCase()) ? preference.toLowerCase() : "regular";
}
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((req, res) => {
    const agent = new WebhookClient({ request: req, response: res });

   // Order Ice Cream Intent
    function handleOrderIceCream(agent) {
        let number = agent.parameters.number;
        let dietary_preference = agent.parameters.dietary_preference;
    
        if (!number || !dietary_preference) {
            agent.add("❓ Can you provide both the number of scoops and your dietary preference?");
            return;
        }
    
        number = normalizeNumber(number);
        dietary_preference = normalizeDietaryPreference(dietary_preference);
    
        if (number < 1 || number > 50) {
            agent.add("😅 Sorry, we can only handle orders between 1 and 50 scoops. How many would you like?");
            return;
        }
    
        gent.context.set({
            name: 'order-confirmation', 
            lifespan: 5,
            parameters: { number, dietary_preference }
        });
    
        agent.add(`📝 Confirm order: ${number} ${dietary_preference} ice cream${number > 1 ? 's' : ''}. Say 'yes' or 'correct' to confirm.`);
    
        }
    
	// Order Confirming Intent to confirm before placing the order
        function handleOrderConfirmation(agent) {
            const context = agent.context.get('order-confirmation');
            if (!context) {
                agent.add("⚠️ No active order to confirm.");
                return;
            }
        
            // Deleting ALL conflicting contexts
            agent.context.delete('order-followup');
            agent.context.delete('ordericecreamintent');
            agent.context.delete('orderfollowupintent');
            agent.context.delete('order-confirmation'); // Clear the confirmation context
        
            const { number, dietary_preference } = context.parameters;
            const userResponse = agent.query.toLowerCase();
        
            if (userResponse.match(/(correct|confirm)/)) {
                agent.add(`✅ Confirmed! ${number} ${dietary_preference} ice cream${number > 1 ? 's' : ''} ordered!`);
            } else {
                agent.add("❌ Order cancelled.");
            }
        }
  
	// Finding Ice cream shop Intent
  
    function handleFindIceCreamShop(agent) {
        let location = agent.parameters["geo-city"];
        let flavor = agent.parameters["flavor"];
        let dietaryPreference = agent.parameters["dietary_preference"];

        if (Array.isArray(location) && location.length > 0) location = location[0];
        if (Array.isArray(flavor) && flavor.length > 0) flavor = flavor[0];
        if (Array.isArray(dietaryPreference) && dietaryPreference.length > 0) dietaryPreference = dietaryPreference[0];

        if (!location) {
            agent.add("🌎 Which city are you looking for ice cream shops in?");
            return;
        }

        let filteredShops = iceCreamShops.filter(shop => 
            shop.location.toLowerCase() === location.toLowerCase() &&
            (!flavor || shop.flavors.includes(flavor.toLowerCase())) &&
            (!dietaryPreference || shop.dietaryOptions.includes(dietaryPreference.toLowerCase()))
        );

        if (filteredShops.length === 0) {
            agent.add(`❌ I couldn't find any ice cream shops in ${location} that match your criteria. Would you like to try again with different options?`);
            return;
        }

        let response = `🍦 Here are some ice cream shops in ${location}:\n`;
        filteredShops.forEach((shop, index) => {
            response += `${index + 1}. **${shop.name}** (${shop.area})\n`;
            response += `   🕒 Hours: ${shop.hours}\n`;
            response += `   ⭐ Rating: ${shop.rating}/5\n\n`;
        });

        agent.add(response + "Would you like to place an order? 😊");
    }
  
	// This connects Find Intent with Order Intent with a Followup confirmation
    function handleOrderFollowUp(agent) {
        const userResponse = agent.query.toLowerCase();

        if (userResponse.match(/(yes|sure|okay|yep|yeah)/)) {
            agent.context.set({
                name: 'order-followup',
                lifespan: 5,
                parameters: {}  
            });
            agent.add("Great! How many scoops would you like and what's your dietary preference (regular, vegan, sugar-free, gluten-free, dairy-free)?");
        } else {
            agent.add("No problem! Have a sweet day! 😊");
        }
    }

    const intentMap = new Map();
    intentMap.set("OrderFollowUpIntent", handleOrderFollowUp);
    intentMap.set("OrderIceCreamIntent", handleOrderIceCream);
    intentMap.set("OrderConfirmationIntent", handleOrderConfirmation);
    intentMap.set("FindIceCreamShopIntent", handleFindIceCreamShop);

    agent.handleRequest(intentMap);
});